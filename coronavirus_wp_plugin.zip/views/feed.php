<div class="widget widget_text">
    <div class="widget-content">
        <div class="feed-header">
            <?php if(isset($displayTitle) && $displayTitle): ?>
                <h2 class="feed-title widget-title subheading heading-size-3">
                    <?php if(isset($title)): ?>
                        <?php echo $title; ?>
                    <?php else: ?>
                        <?php _e( 'Coronavirus Update', 'text_domain' ); ?>
                    <?php endif; ?>
                </h2>
            <?php endif; ?>

            <div class="feed-selector">
                <select>
                    <?php foreach ($feed['regions'] as $region => $data): ?>
                        <option value="<?php echo $region; ?>" <?php echo $selectedRegion === $region ? 'selected' : '' ?>>
                            <?php echo $this->prettyPrintKeyName($region); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="feed-text textwidget">
            <?php if((isset($selectedRegion) && $selectedRegion)): ?>
                <p>
                    In <span data-id="region"><?php echo $this->prettyPrintKeyName($selectedRegion); ?></span>
                    we have <span data-id="total_cases"><?php echo number_format_i18n($regionFeed['total_cases'],0); ?></span> reported cases
                    with <span data-id="active_cases"><?php echo number_format_i18n($regionFeed['total_cases'] - $regionFeed['recovered'] - $regionFeed['deaths'], 0); ?></span> still active.
                    <span data-id="recovered"><?php echo number_format_i18n($regionFeed['recovered'], 0); ?></span> recovered and
                    <span data-id="deaths"><?php echo number_format_i18n($regionFeed['deaths'], 0); ?></span> casualties.
                    The death ratio in <span data-id="region"><?php echo $this->prettyPrintKeyName($selectedRegion); ?></span> is
                    <span data-id="death_ratio"><?php echo number_format_i18n($regionFeed['death_ratio'], 2); ?></span> at the moment,
                    <span data-id="recovery_ratio"><?php echo number_format_i18n($regionFeed['recovery_ratio'], 2); ?></span> is recovering.
                </p>
            <?php else: ?>
                <p>No data available for this region :)</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {})
</script>